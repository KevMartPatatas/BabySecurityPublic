<script setup>
import AlumnoCard from '../components/AlumnoCard.vue';
</script>